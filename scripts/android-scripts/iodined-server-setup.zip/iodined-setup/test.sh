#!/bin/sh

. ./iodined.config

echo "$CONFIG_FOLDER"
