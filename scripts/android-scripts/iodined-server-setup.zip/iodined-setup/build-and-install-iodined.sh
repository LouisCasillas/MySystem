#!/bin/sh -xe

cd iodine-0.7.0
make && make install
