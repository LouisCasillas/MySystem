#!/bin/sh -xe

. iodined.config

if [ -d "/etc/iodined" ]; then

fi

cp keep-iodined-running.sh /etc/iodined/
