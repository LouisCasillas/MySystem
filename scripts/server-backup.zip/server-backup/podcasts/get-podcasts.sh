#!/bin/bash

youtube-dl -U

mkdir -p /root/you/podcasts/
cd /root/you/podcasts/

youtube-dl -c -i -f 249/250/251 \
	--date "$(date +%Y%m%d)" \
	--playlist-end 5 \
	--youtube-skip-dash-manifest \
	https://www.youtube.com/user/PowerfulJRE \
	https://www.youtube.com/channel/UCrlzSqLSGj8GIOeT5jrQsJA \
	https://www.youtube.com/channel/UC9HBtG6DWjs7zzmxL5IuyPw \
	https://www.youtube.com/user/jacktaylor1983/videos \
	https://www.youtube.com/user/ChrisStuckmann/videos

cd /root/you/

rclone copy podcasts/ GoogleDrive:/podcasts/ && \
	rm -rf podcasts/*
